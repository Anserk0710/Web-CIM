<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends Factory<User>
 */
class UserFactory extends Factory
{
    protected static ?string $password;

    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),

            'password' => static::$password ??= Hash::make(
                'password',
            ),

            'is_active' => true,
            'remember_token' => Str::random(10),
            'lock_version' => 1,
        ];
    }

    public function inactive(): static
    {
        return $this->state(
            fn (): array => [
                'is_active' => false,
            ],
        );
    }

    public function unverified(): static
    {
        return $this->state(
            fn (): array => [
                'email_verified_at' => null,
            ],
        );
    }
}
