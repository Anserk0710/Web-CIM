import {
    type ComponentProps,
} from 'react';

import {
    cva,
    type VariantProps,
} from 'class-variance-authority';

import {
    cn,
} from '@/lib/utils';

const buttonVariants = cva(
    [
        'inline-flex items-center justify-center',
        'rounded-lg text-sm font-medium',
        'transition-colors',
        'disabled:pointer-events-none disabled:opacity-50',
        'focus-visible:outline-none',
        'focus-visible:ring-2 focus-visible:ring-ring',
        'focus-visible:ring-offset-2',
    ],
    {
        variants: {
            variant: {
                destructive: [
                    'bg-destructive',
                    'text-destructive-foreground',
                    'hover:bg-destructive/90',
                ],
                default: [
                    'bg-primary',
                    'text-primary-foreground',
                    'hover:bg-cim-navy',
                ],
                secondary: [
                    'bg-secondary',
                    'text-secondary-foreground',
                    'hover:bg-cim-sky',
                ],
                outline: [
                    'border',
                    'border-border',
                    'bg-background',
                    'text-foreground',
                    'hover:bg-muted',
                ],
                ghost: [
                    'text-foreground',
                    'hover:bg-muted',
                ],
            },

            size: {
                default: 'h-10 px-4 py-2',
                sm: 'h-9 px-3',
                lg: 'h-11 px-6',
            },
        },

        defaultVariants: {
            variant: 'default',
            size: 'default',
        },
    },
);

type ButtonProps =
    ComponentProps<'button'>
    & VariantProps<typeof buttonVariants>;

function Button({
    className,
    variant,
    size,
    type = 'button',
    ...props
}: ButtonProps) {
    return (
        <button
            type={type}
            className={cn(
                buttonVariants({
                    variant,
                    size,
                }),
                className,
            )}
            {...props}
        />
    );
}

export {
    Button,
    buttonVariants,
};
