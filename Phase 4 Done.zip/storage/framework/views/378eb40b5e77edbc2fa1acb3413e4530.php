

<?php $__env->startSection(
    'title',
    $revision->seo_title ?: $revision->name
); ?>

<?php $__env->startSection(
    'meta_description',
    $revision->seo_description
    ?: ($revision->summary ?: $revision->name)
); ?>

<?php if($preview): ?>
<?php $__env->startSection('robots', 'noindex,nofollow'); ?>
<?php else: ?>
<?php $__env->startSection(
    'canonical',
    route(
        'products.show',
        $product->public_slug
    )
); ?>
<?php endif; ?>

<?php if($revision->ogMedia): ?>
<?php $__env->startSection(
    'og_image',
    $revision->ogMedia->url()
); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <?php
        $gallery = $revision
            ->media
            ->where(
                'role',
                $galleryRole
            )
            ->values();

        $brochure = $revision
            ->media
            ->firstWhere(
                'role',
                $brochureRole
            );
    ?>

    <?php if($preview): ?>
        <div class="bg-amber-100 px-4 py-3 text-center text-sm font-semibold text-amber-900">
            Authenticated preview — WORKING revision. Halaman ini bukan konten live.
        </div>
    <?php endif; ?>

    <section class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div class="grid gap-10 lg:grid-cols-2">
            <div>
                <?php if($gallery->isNotEmpty()): ?>
                    <img src="<?php echo e($gallery->first()->media->url()); ?>" alt="<?php echo e($gallery->first()->alt_text ?: $revision->name); ?>"
                        class="aspect-[4/3] w-full rounded-2xl border object-cover">

                    <?php if($gallery->count() > 1): ?>
                        <div class="mt-4 grid grid-cols-4 gap-3">
                            <?php $__currentLoopData = $gallery->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e($item->media->url()); ?>" alt="<?php echo e($item->alt_text ?: $revision->name); ?>"
                                    class="aspect-square rounded-lg border object-cover" loading="lazy">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="flex aspect-[4/3] items-center justify-center rounded-2xl bg-muted text-muted-foreground">
                        No product image
                    </div>
                <?php endif; ?>
            </div>

            <div>
                <p class="text-sm font-semibold text-cim-blue">
                    <?php echo e($revision->category->name); ?>

                </p>

                <h1 class="mt-2 text-4xl font-bold tracking-tight text-cim-navy">
                    <?php echo e($revision->name); ?>

                </h1>

                <?php if($revision->brand || $revision->type): ?>
                    <p class="mt-3 text-sm text-muted-foreground">
                        <?php if($revision->brand): ?>
                            <?php echo e($revision->brand->name); ?>

                        <?php endif; ?>

                        <?php if($revision->brand && $revision->type): ?>
                            ·
                        <?php endif; ?>

                        <?php if($revision->type): ?>
                            <?php echo e($revision->type->name); ?>

                        <?php endif; ?>
                    </p>
                <?php endif; ?>

                <?php if($revision->summary): ?>
                    <p class="mt-6 text-lg leading-8 text-slate-600">
                        <?php echo e($revision->summary); ?>

                    </p>
                <?php endif; ?>

                <?php if($revision->highlights->isNotEmpty()): ?>
                    <ul class="mt-6 space-y-2">
                        <?php $__currentLoopData = $revision->highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex gap-3 text-sm">
                                <span class="text-cim-blue">
                                    ✓
                                </span>

                                <span>
                                    <?php echo e($highlight->text); ?>

                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>

                <?php if($brochure): ?>
                    <a href="<?php echo e($brochure->media->url()); ?>" target="_blank" rel="noopener"
                        class="mt-8 inline-flex rounded-lg bg-cim-blue px-5 py-3 text-sm font-semibold text-white">
                        Download brochure
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if($revision->description): ?>
            <section class="mt-14 border-t pt-10">
                <h2 class="text-2xl font-bold text-cim-navy">
                    Description
                </h2>

                <div class="mt-5 whitespace-pre-line leading-7 text-slate-700">
                    <?php echo e($revision->description); ?>

                </div>
            </section>
        <?php endif; ?>

        <?php if($revision->specificationGroups->isNotEmpty()): ?>
            <section class="mt-14 border-t pt-10">
                <h2 class="text-2xl font-bold text-cim-navy">
                    Specifications
                </h2>

                <div class="mt-6 space-y-8">
                    <?php $__currentLoopData = $revision->specificationGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <h3 class="font-semibold text-cim-navy">
                                <?php echo e($group->name); ?>

                            </h3>

                            <dl class="mt-3 divide-y rounded-xl border">
                                <?php $__currentLoopData = $group->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="grid grid-cols-2 gap-4 p-4">
                                        <dt class="font-medium">
                                            <?php echo e($item->label); ?>

                                        </dt>

                                        <dd>
                                            <?php echo e($item->value); ?>


                                            <?php if($item->unit): ?>
                                                <?php echo e($item->unit); ?>

                                            <?php endif; ?>
                                        </dd>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </dl>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($revision->relatedProducts->isNotEmpty()): ?>
            <section class="mt-14 border-t pt-10">
                <h2 class="text-2xl font-bold text-cim-navy">
                    Related Products
                </h2>

                <div class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    <?php $__currentLoopData = $revision->relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(
                                $related->publishedRevision
                                && $related->public_slug
                            ): ?>
                            <a href="<?php echo e(route('products.show', $related->public_slug)); ?>" class="rounded-xl border p-5">
                                <strong class="text-cim-navy">
                                    <?php echo e($related->publishedRevision->name); ?>

                                </strong>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/public/products/show.blade.php ENDPATH**/ ?>