<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo e(route('home')); ?></loc>
    </url>
    <url>
        <loc><?php echo e(route('products.index')); ?></loc>
    </url>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(route('products.show', $product->public_slug)); ?></loc>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH /var/www/html/resources/views/public/sitemap.blade.php ENDPATH**/ ?>