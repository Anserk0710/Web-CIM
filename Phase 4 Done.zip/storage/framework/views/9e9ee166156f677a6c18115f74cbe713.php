<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>
        <?php echo $__env->yieldContent('title', config('app.name')); ?>
    </title>

    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'PT Cahya Intan Medika'); ?>">

    <?php if (! empty(trim($__env->yieldContent('canonical')))): ?>
        <link rel="canonical" href="<?php echo $__env->yieldContent('canonical'); ?>">
    <?php endif; ?>

    <?php if (! empty(trim($__env->yieldContent('robots')))): ?>
        <meta name="robots" content="<?php echo $__env->yieldContent('robots'); ?>">
    <?php endif; ?>

    <?php if (! empty(trim($__env->yieldContent('og_image')))): ?>
        <meta property="og:image" content="<?php echo $__env->yieldContent('og_image'); ?>">
    <?php endif; ?>

    <meta property="og:title" content="<?php echo $__env->yieldContent('title', config('app.name')); ?>">

    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', 'PT Cahya Intan Medika'); ?>">

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/public.ts'); ?>
</head>

<body>
    <header class="border-b border-border bg-background">
        <div class="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
            <a href="<?php echo e(route('home')); ?>" class="font-bold tracking-tight text-cim-navy">
                PT Cahya Intan Medika
            </a>

            <nav aria-label="Primary navigation" class="flex items-center gap-4 text-sm">
                <a href="<?php echo e(route('home')); ?>" class="font-medium text-foreground hover:text-cim-blue">
                    Home
                </a>

                <a href="<?php echo e(route('products.index')); ?>" class="font-medium text-foreground hover:text-cim-blue">
                    Products
                </a>

                <a href="<?php echo e(route('login')); ?>"
                    class="rounded-lg bg-cim-navy px-4 py-2 font-medium text-white hover:bg-cim-blue">
                    CMS
                </a>
            </nav>
        </div>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="border-t border-border bg-background">
        <div class="mx-auto max-w-7xl px-4 py-8 text-sm text-muted-foreground sm:px-6 lg:px-8">
            &copy; <?php echo e(now()->year); ?> PT Cahya Intan Medika.
        </div>
    </footer>
</body>

</html><?php /**PATH /var/www/html/resources/views/layouts/public.blade.php ENDPATH**/ ?>