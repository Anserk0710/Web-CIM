

<?php $__env->startSection('title', 'Products | PT Cahya Intan Medika'); ?>

<?php $__env->startSection(
    'meta_description',
    'Daftar produk PT Cahya Intan Medika.'
); ?>

<?php $__env->startSection('canonical', route('products.index')); ?>

<?php $__env->startSection('content'); ?>
    <section class="border-b bg-cim-ice/40">
        <div class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
            <h1 class="text-4xl font-bold tracking-tight text-cim-navy">
                Products
            </h1>

            <p class="mt-3 max-w-2xl text-muted-foreground">
                Temukan produk berdasarkan kategori, brand, atau tipe.
            </p>
        </div>
    </section>

    <section class="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <form method="GET" action="<?php echo e(route('products.index')); ?>"
            class="grid gap-4 rounded-2xl border bg-background p-5 md:grid-cols-4">
            <div>
                <label for="q" class="mb-2 block text-sm font-medium">
                    Search
                </label>

                <input id="q" name="q" value="<?php echo e($filters['q']); ?>" class="w-full rounded-lg border border-input px-3 py-2"
                    placeholder="Nama produk...">
            </div>

            <div>
                <label for="category" class="mb-2 block text-sm font-medium">
                    Category
                </label>

                <select id="category" name="category" class="w-full rounded-lg border border-input px-3 py-2">
                    <option value="">
                        Semua
                    </option>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->slug); ?>" <?php if(
                            $filters['category']
                            === $category->slug
                        ): echo 'selected'; endif; ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="brand" class="mb-2 block text-sm font-medium">
                    Brand
                </label>

                <select id="brand" name="brand" class="w-full rounded-lg border border-input px-3 py-2">
                    <option value="">
                        Semua
                    </option>

                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->slug); ?>" <?php if(
                            $filters['brand']
                            === $brand->slug
                        ): echo 'selected'; endif; ?>>
                            <?php echo e($brand->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="type" class="mb-2 block text-sm font-medium">
                    Type
                </label>

                <select id="type" name="type" class="w-full rounded-lg border border-input px-3 py-2">
                    <option value="">
                        Semua
                    </option>

                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->slug); ?>" <?php if(
                            $filters['type']
                            === $type->slug
                        ): echo 'selected'; endif; ?>>
                            <?php echo e($type->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="md:col-span-4">
                <button type="submit" class="rounded-lg bg-cim-blue px-5 py-2.5 text-sm font-semibold text-white">
                    Apply filter
                </button>
            </div>
        </form>

        <?php if($products->isEmpty()): ?>
            <div class="mt-10 rounded-2xl border border-dashed p-10 text-center">
                <h2 class="font-semibold text-cim-navy">
                    Product tidak ditemukan
                </h2>
            </div>
        <?php else: ?>
            <div class="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $revision = $product->publishedRevision;

                        $cover = $revision
                            ->media
                            ->firstWhere(
                                'role',
                                $galleryRole,
                            );
                    ?>

                    <article class="overflow-hidden rounded-2xl border bg-background">
                        <?php if($cover): ?>
                            <img src="<?php echo e($cover->media->url()); ?>" alt="<?php echo e($cover->alt_text ?: $revision->name); ?>"
                                class="aspect-[4/3] w-full object-cover" loading="lazy">
                        <?php endif; ?>

                        <div class="p-5">
                            <p class="text-sm font-medium text-cim-blue">
                                <?php echo e($revision->category->name); ?>

                            </p>

                            <h2 class="mt-2 text-xl font-semibold text-cim-navy">
                                <a href="<?php echo e(route('products.show', $product->public_slug)); ?>">
                                    <?php echo e($revision->name); ?>

                                </a>
                            </h2>

                            <?php if($revision->summary): ?>
                                <p class="mt-3 text-sm leading-6 text-muted-foreground">
                                    <?php echo e($revision->summary); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($products->hasPages()): ?>
                <nav class="mt-10 flex items-center justify-between" aria-label="Pagination">
                    <?php if($products->onFirstPage()): ?>
                        <span class="text-sm text-muted-foreground">
                            Previous
                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($products->previousPageUrl()); ?>" class="text-sm font-semibold text-cim-blue">
                            Previous
                        </a>
                    <?php endif; ?>

                    <span class="text-sm text-muted-foreground">
                        Page <?php echo e($products->currentPage()); ?>

                        of <?php echo e($products->lastPage()); ?>

                    </span>

                    <?php if($products->hasMorePages()): ?>
                        <a href="<?php echo e($products->nextPageUrl()); ?>" class="text-sm font-semibold text-cim-blue">
                            Next
                        </a>
                    <?php else: ?>
                        <span class="text-sm text-muted-foreground">
                            Next
                        </span>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/public/products/index.blade.php ENDPATH**/ ?>