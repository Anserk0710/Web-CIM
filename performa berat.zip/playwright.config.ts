import {
    defineConfig,
    devices,
} from '@playwright/test';

export default defineConfig({
    testDir: './tests/e2e',

    fullyParallel: false,

    forbidOnly: Boolean(process.env.CI),

    retries: process.env.CI ? 1 : 0,

    workers: 1,

    reporter: process.env.CI
        ? 'github'
        : 'list',

    use: {
        baseURL:
            process.env.PLAYWRIGHT_BASE_URL
            ?? 'http://localhost:8080',

        trace: 'retain-on-failure',

        screenshot: 'only-on-failure',
    },

    projects: [
        {
            name: 'chromium',

            use: {
                ...devices['Desktop Chrome'],
            },
        },
    ],
});